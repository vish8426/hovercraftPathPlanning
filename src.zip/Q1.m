%by 470416309
%
%the following function creates a wind field plotted as vectors upon a x,y
%coordinate plane from origin (0,0) to limit (100,100) and plots the
%simulated dynamics of an object being influenced by the wind effects

%clear of figures, workspace and screen
clear;
clc;
clf;

%map parameters
MaxWind = 1;
gridSize = 30;
dimensions = 100;
kernelWidth = 15;

%sample random fields
xs = linspace(0,dimensions,gridSize);
[X,Y] = meshgrid(xs);
K = ones(kernelWidth,kernelWidth);

U = randn(gridSize,gridSize);
V = randn(gridSize,gridSize);

out = sim('Simulink_Model_Q1_2');

%smooth out via convolution
Uc = conv2(U,K,'same');
Vc = conv2(V,K,'same');

%set maximum wind speed
mv = max(max(sqrt(Uc.^2+Vc.^2)));

Uc = Uc*MaxWind/mv;
Vc = Vc*MaxWind/mv;

%plot to wind field
figure(1);
quiver(X,Y,Uc,Vc);
axis equal
hold on;

%plot hovercraft path simulation
plot(out.x.signals.values,out.y.signals.values,'r-');
title('Simulated Model - Hovercraft Dynamics');
xlabel('x-coordinates');
ylabel('y-coordinates');
legend('wind vectors','path');
hold off;