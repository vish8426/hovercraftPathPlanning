%by 470416309
%
%following file is used to calculate specifications and state space design
%in order to model the dynamics and manufacture the control system

%clear of figures, workspace and screen
clear
clc

%specifications of the state space model
Fs = 2;
Fp = 2;
theta = 0;
l = 0.1;

%calculating F matrix
F = [(Fs+Fp)*cos(theta);(Fs+Fp)*sin(theta);(Fs-Fp)*l];

%calculating the u matrix
u = [Fs;Fp];

%calculating k value
E = F/u;

%calculating D matrix
D = [4,0,0;0,4,0;0,0,0.4];

%calculating M matrix
M = [5,0,0;0,5,0;0,0,0.05];

%calculating first partial derivative
Part_Der_FX = -D/M;