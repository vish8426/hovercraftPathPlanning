%by 470416309
%
%this file allows for the determination of the shortest path over a set of
%randomly generated points upon a wind field, furthermore, denoting the
%control of the hovercraft over this path

%clear of figures, workspace and screen
clear;
clc;
clf;

%map parameters
MaxWind = 1;
gridSize = 30;
dimensions = 100;
kernelWidth = 15;

%sample random fields
xs = linspace(0,dimensions,gridSize);
[X,Y] = meshgrid(xs);
K = ones(kernelWidth,kernelWidth);

U = randn(gridSize,gridSize);
V = randn(gridSize,gridSize);

%smooth out via convolution
Uc = conv2(U,K,'same');
Vc = conv2(V,K,'same');

%set maximum wind speed
mv = max(max(sqrt(Uc.^2+Vc.^2)));

Uc = Uc*MaxWind/mv;
Vc = Vc*MaxWind/mv;

%plotting of the wind field 
figure(1);
quiver(X,Y,Uc,Vc);
axis equal
hold on;

%plot of the hovercraft dynamics with influence by wind effects
%plot(out.x.signals.values,out.y.signals.values,'r-');

%create a random set of points
rand_x = randsample(100,10);
rand_y = randsample(100,10);

%define hovercraft start and endpoints
startpoint = 0;
endpoint = 100;

%define number of points 
N = 50;

%save point locations independently into arrays
x_rand = zeros(N);
y_rand = zeros(N);

%set first location to be that of the origin
x_rand(1) = 0;
y_rand(1) = 0;

%set the final location to be that of the endpoint
x_rand(N) = 100;
y_rand(N) = 100;

%run a loop to save all locations of points
for i = 2:N-1
    
    x_rand(i) = rand()*100;
    y_rand(i) = rand()*100;
    
    if      x_rand(i) == x_rand(i-1)
       
            x_rand(i) = rand()*100;
        
    elseif  y_rand(i) == y_rand(i-1)
        
            y_rand(i) = rand()*100;
    end
end

%plot points onto wind field
plot(x_rand,y_rand,'bo');

%employ Dijkstra's Algorithm
coordinates = zeros(N,2);
i = 1;
j = 1;

for r = 1:N
   for c = 1:2
       
       if c == 1
           
           coordinates(r,c) = x_rand(i);
           i = i + 1;
       elseif c == 2
           
           coordinates(r,c) = y_rand(j);
           j = j + 1;
       end
   end
end

k = 1;
r = 1;

while r ~= 0
    
    PQ = coordinates(k,:);
    coordinates(k,:) = [];
    
    if PQ(1,1) == 100 || PQ(1,2) == 100
        
        arr_point_x(r) = 100;
        arr_point_y(r) = 100;
        break;
    end
    
    %search for next closest point location
    [k,dist] = dsearchn(coordinates,PQ);
    arr_dist(1,r) = dist;
    arr_point_x(r) = PQ(1,1);
    arr_point_y(r) = PQ(1,2);
    
    r = r + 1;
end

%plot path onto wind field
plot(arr_point_x,arr_point_y,'LineWidth',2.0);
title('Shortest Path (Dijkstra’s Algorithm)');
xlabel('x-coordinates');
ylabel('y-coordinates');
legend('Location','northwest');
legend('Wind Vectors','Points');

%output data from Simulink Model
out = sim('Simulink_Model_Q1_3');

hold off;